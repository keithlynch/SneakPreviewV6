package org.switchyard.migration.gatewaysrouters;

public interface SimpleService {
	
	void process(String message);
	
}
