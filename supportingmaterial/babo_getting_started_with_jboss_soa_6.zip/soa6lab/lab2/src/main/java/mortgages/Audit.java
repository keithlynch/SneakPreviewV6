package mortgages;

public interface Audit {

	void recordApplication(Applicant applicant);
}
