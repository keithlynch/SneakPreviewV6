package org.switchyard.migration.bpm;

public interface OrchestrationService {

	String process(String message);
}
