package mortgages;

public interface IncomeAdjustment {

	 Applicant adjust(Applicant applicant);
	 
}
