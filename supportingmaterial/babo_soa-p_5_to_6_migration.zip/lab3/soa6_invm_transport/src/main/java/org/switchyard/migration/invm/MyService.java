package org.switchyard.migration.invm;

public interface MyService {

	String process(String message);
}
