package mortgages;

public interface QualificationService {

    Applicant qualify(Applicant applicant);
}
