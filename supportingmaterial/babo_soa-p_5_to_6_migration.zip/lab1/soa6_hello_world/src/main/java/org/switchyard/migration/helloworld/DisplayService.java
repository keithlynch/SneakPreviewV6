package org.switchyard.migration.helloworld;

public interface DisplayService {

	void display(String message);
	
}
