package mortgages;

public interface CreditService {

	 Applicant assignScore(Applicant applicant);
	 
}
