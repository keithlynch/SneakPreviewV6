package org.switchyard.migration.gatewaysrouters;

public interface PrintService {

	void print(String message);
}
