package mortgages;

public interface LoanProcessing {

    void process(Applicant applicant);
}
