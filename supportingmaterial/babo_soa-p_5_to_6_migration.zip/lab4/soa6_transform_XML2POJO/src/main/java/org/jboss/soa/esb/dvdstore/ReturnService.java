package org.jboss.soa.esb.dvdstore;

public interface ReturnService {

}
